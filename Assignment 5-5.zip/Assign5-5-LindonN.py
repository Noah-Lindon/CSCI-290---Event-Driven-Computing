# This program demonstrates adding an image.
# When the user clicks the Button, an
# info dialog box is displayed.

import tkinter
import tkinter.messagebox

class MyGUI:
    def __init__(self):
        # Create the main window widget.
        self.main_window = tkinter.Tk()
        self.top_frame = tkinter.Frame(self.main_window)
        self.bottom_frame = tkinter.Frame(self.main_window)
        # Create the PhotoImage, then load image to a label
        self.logo = tkinter.PhotoImage(file="prism.gif")
        self.labelImage= tkinter.Label(self.top_frame, image=self.logo)
        self.label1 = tkinter.Label(self.main_window,
                                   text='Look at my cool green!',
                                   fg = "dark green",
                                   bg = "black",
                                   underline = 1)
        self.label2 = tkinter.Label(self.main_window,
                                   text='Look at my cool red!',
                                   fg = "red",
                                   bg = "black",
                                   underline = 1)
        self.label3 = tkinter.Label(self.main_window,
                                   text='Look at my cool yellow!',
                                   fg = "yellow",
                                   bg = "black",
                                   underline = 1)
        
        

        # Create a Button widget. The text 'Click Me!'
        # should appear on the face of the Button. The
        # do_something method should be executed when
        # the user clicks the Button.
        self.my_button = tkinter.Button(self.bottom_frame, \
                                        text='Click Me!', \
                                        command=self.do_something)

        # Create a Quit button. When this button is clicked
        # the root widget's destroy method is called.
        # (The main_window variable references the root widget,
        # so the callback function is self.main_window.destroy.)
        self.quit_button = tkinter.Button(self.bottom_frame,
                                          text='Quit',
                                          command=self.main_window.destroy)


        # Pack.       
        self.labelImage.pack(side="right")
        self.label1.pack(side="top")
        self.label2.pack(side="top")
        self.label3.pack(side="top")
        
        self.my_button.pack(side="left")
        self.quit_button.pack(side="right")
        
        self.top_frame.pack()
        self.bottom_frame.pack()
        
        # Enter the tkinter main loop.
        tkinter.mainloop()

    # The do_something method is a callback function
    # for the Button widget.
    
    def do_something(self):
        # Display an info dialog box.
        tkinter.messagebox.showinfo('Response', \
                                    'Thanks for clicking the button.')

# Create an instance of the MyGUI class.
my_gui = MyGUI()

