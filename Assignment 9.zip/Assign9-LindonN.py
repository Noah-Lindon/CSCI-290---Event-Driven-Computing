# Noah Lindon
# CSCI 290
# 4/12/20
# This program demonstrates a menubar in tkinter.
# This program has two tabs at the top of the window


from tkinter import *           # Now we do not have to type tkinter all the time
from tkinter import messagebox  # Still need to import messagebox
from tkinter import ttk         # Needed for combobox and more advanced widgets

class MyGUI:
    def __init__(self):
        # Create the main window widget.
        self.main_window = Tk() 

        #Create title for the main window.
        #You might need to make the window bigger to display the title.
        self.main_window.title("Noah's Menu Items")

        #Create the menubar in tkinter
        self.menubar = Menu(self.main_window)
        
        #Home Tab        
        self.homemenu = Menu(self.menubar, tearoff=0)   #tearoff=0 means do not put menu in its own window
        self.homemenu.add_command(label="Documents", command=self.dodocuments)
        self.homemenu.add_command(label="Pictures", command=self.dopictures)
        self.homemenu.add_command(label="Settings", command=self.dosettings)
        self.homemenu.add_separator()                #This is the line before the Exit menu item
        self.homemenu.add_command(label="Quit", command=self.main_window.destroy)    #Similar to what happens with the quit button
        self.menubar.add_cascade(label="Home", menu=self.homemenu)

        #Help tab
        self.appsmenu = Menu(self.menubar, tearoff=0)
        self.appsmenu.add_command(label="Netflix", command=self.donetflix)
        self.appsmenu.add_command(label="Twitch", command=self.dotwitch)
        self.appsmenu.add_separator()
        self.appsmenu.add_command(label="Spotify", command=self.dospotify)
        self.menubar.add_cascade(label="Apps", menu=self.appsmenu)
        
        #Notification tab
        self.notificationmenu = Menu(self.menubar, tearoff=0)
        self.notificationmenu.add_command(label="Email", command=self.doemail)
        self.notificationmenu.add_command(label="Steam", command=self.dosteam)
        self.notificationmenu.add_separator()
        self.notificationmenu.add_command(label="Discord", command=self.dodiscord)
        self.menubar.add_cascade(label="Notifications", menu=self.notificationmenu)
                
        #Create a label in ttk and pack it - no grid today
        self.logo = PhotoImage(file="hank.gif")
        self.labelImage= Label(self.main_window, image=self.logo)
        self.label = ttk.Label(self.main_window, text = "This is assignment 9. This program includes different menu items. \n")
        self.labelImage.pack()
        self.label.pack()

        #Configure the menu
        self.main_window.config(menu=self.menubar)
        
        # Enter the main loop.
        mainloop()
                
    # For now, when a menu item is selected
    def dodocuments(self):
        #Do absolutely nothing
        print("I am opening your documents")
        
    def dopictures(self):
        #Do absolutely nothing
        print("I am opening your pictures")
        
    def dosettings(self):
        #Do absolutely nothing
        print("I am opening the settings")
        
    def donetflix(self):
        #Do absolutely nothing
        print("I am launching the Netflix app")
        
    def dotwitch(self):
        #Do absolutely nothing
        print("I am launching the Twitch.tv app")
        
    def dospotify(self):
        #Do absolutely nothing
        print("I am launching the Spotify app")
        
    def doemail(self):
        #Do absolutely nothing
        messagebox.showinfo('Email', 'You have 4 unread emails')
        print("I am opening your email")
        
    def dosteam(self):
        #Do absolutely nothing
        messagebox.showinfo('Steam', 'You have 0 steam messages')
        print("I am opening Steam")
        
    def dodiscord(self):
        #Do absolutely nothing
        messagebox.showinfo('Discord', 'You have 5004 discord mentions')
        print("I am opening Discord")
           

# Create an instance of the MyGUI class.
my_gui = MyGUI()

